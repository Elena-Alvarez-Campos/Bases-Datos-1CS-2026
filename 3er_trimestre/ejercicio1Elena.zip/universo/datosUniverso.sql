
/*proveedores*/
insert into proveedores values(1,'Marble Lily',986456789,'www.marblelily.com');
insert into proveedores values(2,'April Bombom',987654321,'www.aprilbombom.com');
insert into proveedores values(3,'Chorale',986745123,'www.Chorale.com');
insert into proveedores values(4,'AZUSA',986123456,'www.azusa.com');
insert into proveedores values(5,'Enid Chien',986741523,'www.enidchien.com');
/*clientes*/
insert into clientes values('12345678A','An','Muros',3,3265,'Gondomar');
insert into clientes values('98765432B','Marina','Aragón',6,3145,'Vigo');
insert into clientes values('74185220C','Pepe','Santiago',12,3894,'Santiago');
insert into clientes values('96385201D','Ena','Calleado',9,3458,'Ramallosa');
insert into clientes values('45623183E','Marco','Ruísima',3535,'Pontevedra');
/*ventas*/
insert into ventas values(1,'2026/04/15','12345678A');
insert into ventas values(2,'2025/04/21','74185220C');
insert into ventas values(3,'1926/08/09','45623183E');
insert into ventas values(4,'2026/11/05','96385201D');
insert into ventas values(5,'2025/10/11','98765432B');
/*artículos*/
insert into articulos values(1);
insert into articulos values(2);
insert into articulos values(3);
insert into articulos values(4);
insert into articulos values(5);
/*artículosVentas*/
insert into articulosVentas values();
insert into articulosVentas values();
insert into articulosVentas values();
insert into articulosVentas values();
insert into articulosVentas values();